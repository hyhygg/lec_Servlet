package lesson02.get;

public interface Operator {
	public String getName();
	public double execute(double a,double b)throws Exception;
}
